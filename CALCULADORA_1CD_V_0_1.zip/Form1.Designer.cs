﻿namespace CALCULADORA_1CD_V_0_1
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.label1 = new System.Windows.Forms.Label();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.bt_MC = new System.Windows.Forms.Button();
            this.bt_MR = new System.Windows.Forms.Button();
            this.bt_MS = new System.Windows.Forms.Button();
            this.bt_CE = new System.Windows.Forms.Button();
            this.bt_c = new System.Windows.Forms.Button();
            this.bt_7 = new System.Windows.Forms.Button();
            this.bt_8 = new System.Windows.Forms.Button();
            this.bt_9 = new System.Windows.Forms.Button();
            this.bt_6 = new System.Windows.Forms.Button();
            this.bt_5 = new System.Windows.Forms.Button();
            this.bt_4 = new System.Windows.Forms.Button();
            this.bt_3 = new System.Windows.Forms.Button();
            this.bt_2 = new System.Windows.Forms.Button();
            this.bt_1 = new System.Windows.Forms.Button();
            this.bt_0 = new System.Windows.Forms.Button();
            this.bt_vírgula = new System.Windows.Forms.Button();
            this.bt_soma = new System.Windows.Forms.Button();
            this.bt_subtração = new System.Windows.Forms.Button();
            this.bt_multiplicação = new System.Windows.Forms.Button();
            this.bt_divisão = new System.Windows.Forms.Button();
            this.bt_igual = new System.Windows.Forms.Button();
            this.lb_M = new System.Windows.Forms.Label();
            this.bt_porcentagem = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(208, 13);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(34, 13);
            this.label1.TabIndex = 0;
            this.label1.Text = "Ajuda";
            this.label1.Click += new System.EventHandler(this.label1_Click);
            // 
            // textBox1
            // 
            this.textBox1.Enabled = false;
            this.textBox1.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox1.Location = new System.Drawing.Point(11, 39);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(231, 31);
            this.textBox1.TabIndex = 1;
            // 
            // bt_MC
            // 
            this.bt_MC.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bt_MC.Location = new System.Drawing.Point(12, 76);
            this.bt_MC.Name = "bt_MC";
            this.bt_MC.Size = new System.Drawing.Size(41, 30);
            this.bt_MC.TabIndex = 2;
            this.bt_MC.Text = "MC";
            this.bt_MC.UseVisualStyleBackColor = true;
            this.bt_MC.Click += new System.EventHandler(this.bt_MC_Click);
            // 
            // bt_MR
            // 
            this.bt_MR.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bt_MR.Location = new System.Drawing.Point(59, 76);
            this.bt_MR.Name = "bt_MR";
            this.bt_MR.Size = new System.Drawing.Size(41, 30);
            this.bt_MR.TabIndex = 3;
            this.bt_MR.Text = "MR";
            this.bt_MR.UseVisualStyleBackColor = true;
            this.bt_MR.Click += new System.EventHandler(this.bt_MR_Click);
            // 
            // bt_MS
            // 
            this.bt_MS.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bt_MS.Location = new System.Drawing.Point(106, 76);
            this.bt_MS.Name = "bt_MS";
            this.bt_MS.Size = new System.Drawing.Size(41, 30);
            this.bt_MS.TabIndex = 4;
            this.bt_MS.Text = "MS";
            this.bt_MS.UseVisualStyleBackColor = true;
            this.bt_MS.Click += new System.EventHandler(this.bt_MS_Click);
            // 
            // bt_CE
            // 
            this.bt_CE.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bt_CE.Location = new System.Drawing.Point(59, 112);
            this.bt_CE.Name = "bt_CE";
            this.bt_CE.Size = new System.Drawing.Size(41, 30);
            this.bt_CE.TabIndex = 5;
            this.bt_CE.Text = "CE";
            this.bt_CE.UseVisualStyleBackColor = true;
            this.bt_CE.Click += new System.EventHandler(this.bt_CE_Click);
            // 
            // bt_c
            // 
            this.bt_c.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bt_c.Location = new System.Drawing.Point(106, 112);
            this.bt_c.Name = "bt_c";
            this.bt_c.Size = new System.Drawing.Size(41, 30);
            this.bt_c.TabIndex = 6;
            this.bt_c.Text = "C";
            this.bt_c.UseVisualStyleBackColor = true;
            this.bt_c.Click += new System.EventHandler(this.bt_c_Click);
            // 
            // bt_7
            // 
            this.bt_7.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bt_7.Location = new System.Drawing.Point(12, 148);
            this.bt_7.Name = "bt_7";
            this.bt_7.Size = new System.Drawing.Size(41, 30);
            this.bt_7.TabIndex = 7;
            this.bt_7.Text = "7";
            this.bt_7.UseVisualStyleBackColor = true;
            this.bt_7.Click += new System.EventHandler(this.bt_7_Click);
            // 
            // bt_8
            // 
            this.bt_8.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bt_8.Location = new System.Drawing.Point(59, 148);
            this.bt_8.Name = "bt_8";
            this.bt_8.Size = new System.Drawing.Size(41, 30);
            this.bt_8.TabIndex = 8;
            this.bt_8.Text = "8";
            this.bt_8.UseVisualStyleBackColor = true;
            this.bt_8.Click += new System.EventHandler(this.bt_8_Click);
            // 
            // bt_9
            // 
            this.bt_9.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bt_9.Location = new System.Drawing.Point(106, 148);
            this.bt_9.Name = "bt_9";
            this.bt_9.Size = new System.Drawing.Size(41, 30);
            this.bt_9.TabIndex = 9;
            this.bt_9.Text = "9";
            this.bt_9.UseVisualStyleBackColor = true;
            this.bt_9.Click += new System.EventHandler(this.bt_9_Click);
            // 
            // bt_6
            // 
            this.bt_6.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bt_6.Location = new System.Drawing.Point(106, 184);
            this.bt_6.Name = "bt_6";
            this.bt_6.Size = new System.Drawing.Size(41, 30);
            this.bt_6.TabIndex = 12;
            this.bt_6.Text = "6";
            this.bt_6.UseVisualStyleBackColor = true;
            this.bt_6.Click += new System.EventHandler(this.bt_6_Click);
            // 
            // bt_5
            // 
            this.bt_5.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bt_5.Location = new System.Drawing.Point(59, 184);
            this.bt_5.Name = "bt_5";
            this.bt_5.Size = new System.Drawing.Size(41, 30);
            this.bt_5.TabIndex = 11;
            this.bt_5.Text = "5";
            this.bt_5.UseVisualStyleBackColor = true;
            this.bt_5.Click += new System.EventHandler(this.bt_5_Click);
            // 
            // bt_4
            // 
            this.bt_4.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bt_4.Location = new System.Drawing.Point(12, 184);
            this.bt_4.Name = "bt_4";
            this.bt_4.Size = new System.Drawing.Size(41, 30);
            this.bt_4.TabIndex = 10;
            this.bt_4.Text = "4";
            this.bt_4.UseVisualStyleBackColor = true;
            this.bt_4.Click += new System.EventHandler(this.bt_4_Click);
            // 
            // bt_3
            // 
            this.bt_3.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bt_3.Location = new System.Drawing.Point(106, 220);
            this.bt_3.Name = "bt_3";
            this.bt_3.Size = new System.Drawing.Size(41, 30);
            this.bt_3.TabIndex = 15;
            this.bt_3.Text = "3";
            this.bt_3.UseVisualStyleBackColor = true;
            this.bt_3.Click += new System.EventHandler(this.bt_3_Click);
            // 
            // bt_2
            // 
            this.bt_2.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bt_2.Location = new System.Drawing.Point(59, 220);
            this.bt_2.Name = "bt_2";
            this.bt_2.Size = new System.Drawing.Size(41, 30);
            this.bt_2.TabIndex = 14;
            this.bt_2.Text = "2";
            this.bt_2.UseVisualStyleBackColor = true;
            this.bt_2.Click += new System.EventHandler(this.bt_2_Click);
            // 
            // bt_1
            // 
            this.bt_1.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bt_1.Location = new System.Drawing.Point(12, 220);
            this.bt_1.Name = "bt_1";
            this.bt_1.Size = new System.Drawing.Size(41, 30);
            this.bt_1.TabIndex = 13;
            this.bt_1.Text = "1";
            this.bt_1.UseVisualStyleBackColor = true;
            this.bt_1.Click += new System.EventHandler(this.bt_1_Click);
            // 
            // bt_0
            // 
            this.bt_0.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bt_0.Location = new System.Drawing.Point(12, 256);
            this.bt_0.Name = "bt_0";
            this.bt_0.Size = new System.Drawing.Size(88, 30);
            this.bt_0.TabIndex = 16;
            this.bt_0.Text = "0";
            this.bt_0.UseVisualStyleBackColor = true;
            this.bt_0.Click += new System.EventHandler(this.bt_0_Click);
            // 
            // bt_vírgula
            // 
            this.bt_vírgula.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bt_vírgula.Location = new System.Drawing.Point(106, 256);
            this.bt_vírgula.Name = "bt_vírgula";
            this.bt_vírgula.Size = new System.Drawing.Size(41, 30);
            this.bt_vírgula.TabIndex = 17;
            this.bt_vírgula.Text = ",";
            this.bt_vírgula.UseVisualStyleBackColor = true;
            this.bt_vírgula.Click += new System.EventHandler(this.bt_vírgula_Click);
            // 
            // bt_soma
            // 
            this.bt_soma.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bt_soma.Location = new System.Drawing.Point(153, 256);
            this.bt_soma.Name = "bt_soma";
            this.bt_soma.Size = new System.Drawing.Size(41, 30);
            this.bt_soma.TabIndex = 21;
            this.bt_soma.Text = "+";
            this.bt_soma.UseVisualStyleBackColor = true;
            this.bt_soma.Click += new System.EventHandler(this.bt_soma_Click);
            // 
            // bt_subtração
            // 
            this.bt_subtração.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bt_subtração.Location = new System.Drawing.Point(153, 220);
            this.bt_subtração.Name = "bt_subtração";
            this.bt_subtração.Size = new System.Drawing.Size(41, 30);
            this.bt_subtração.TabIndex = 20;
            this.bt_subtração.Text = "-";
            this.bt_subtração.UseVisualStyleBackColor = true;
            this.bt_subtração.Click += new System.EventHandler(this.bt_subtração_Click);
            // 
            // bt_multiplicação
            // 
            this.bt_multiplicação.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bt_multiplicação.Location = new System.Drawing.Point(153, 184);
            this.bt_multiplicação.Name = "bt_multiplicação";
            this.bt_multiplicação.Size = new System.Drawing.Size(41, 30);
            this.bt_multiplicação.TabIndex = 19;
            this.bt_multiplicação.Text = "*";
            this.bt_multiplicação.UseVisualStyleBackColor = true;
            this.bt_multiplicação.Click += new System.EventHandler(this.bt_multiplicação_Click);
            // 
            // bt_divisão
            // 
            this.bt_divisão.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bt_divisão.Location = new System.Drawing.Point(153, 148);
            this.bt_divisão.Name = "bt_divisão";
            this.bt_divisão.Size = new System.Drawing.Size(41, 30);
            this.bt_divisão.TabIndex = 18;
            this.bt_divisão.Text = "/";
            this.bt_divisão.UseVisualStyleBackColor = true;
            this.bt_divisão.Click += new System.EventHandler(this.bt_divisão_Click);
            // 
            // bt_igual
            // 
            this.bt_igual.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bt_igual.Location = new System.Drawing.Point(200, 220);
            this.bt_igual.Name = "bt_igual";
            this.bt_igual.Size = new System.Drawing.Size(41, 66);
            this.bt_igual.TabIndex = 22;
            this.bt_igual.Text = "=";
            this.bt_igual.UseVisualStyleBackColor = true;
            this.bt_igual.Click += new System.EventHandler(this.bt_igual_Click);
            // 
            // lb_M
            // 
            this.lb_M.AutoSize = true;
            this.lb_M.Location = new System.Drawing.Point(13, 20);
            this.lb_M.Name = "lb_M";
            this.lb_M.Size = new System.Drawing.Size(16, 13);
            this.lb_M.TabIndex = 23;
            this.lb_M.Text = "M";
            // 
            // bt_porcentagem
            // 
            this.bt_porcentagem.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bt_porcentagem.Location = new System.Drawing.Point(153, 112);
            this.bt_porcentagem.Name = "bt_porcentagem";
            this.bt_porcentagem.Size = new System.Drawing.Size(41, 30);
            this.bt_porcentagem.TabIndex = 24;
            this.bt_porcentagem.Text = "%";
            this.bt_porcentagem.UseVisualStyleBackColor = true;
            this.bt_porcentagem.Click += new System.EventHandler(this.bt_porcentagem_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(255, 298);
            this.Controls.Add(this.bt_porcentagem);
            this.Controls.Add(this.lb_M);
            this.Controls.Add(this.bt_igual);
            this.Controls.Add(this.bt_soma);
            this.Controls.Add(this.bt_subtração);
            this.Controls.Add(this.bt_multiplicação);
            this.Controls.Add(this.bt_divisão);
            this.Controls.Add(this.bt_vírgula);
            this.Controls.Add(this.bt_0);
            this.Controls.Add(this.bt_3);
            this.Controls.Add(this.bt_2);
            this.Controls.Add(this.bt_1);
            this.Controls.Add(this.bt_6);
            this.Controls.Add(this.bt_5);
            this.Controls.Add(this.bt_4);
            this.Controls.Add(this.bt_9);
            this.Controls.Add(this.bt_8);
            this.Controls.Add(this.bt_7);
            this.Controls.Add(this.bt_c);
            this.Controls.Add(this.bt_CE);
            this.Controls.Add(this.bt_MS);
            this.Controls.Add(this.bt_MR);
            this.Controls.Add(this.bt_MC);
            this.Controls.Add(this.textBox1);
            this.Controls.Add(this.label1);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "Form1";
            this.Text = "Calculadora V 0.2";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.Button bt_MC;
        private System.Windows.Forms.Button bt_MR;
        private System.Windows.Forms.Button bt_MS;
        private System.Windows.Forms.Button bt_CE;
        private System.Windows.Forms.Button bt_c;
        private System.Windows.Forms.Button bt_7;
        private System.Windows.Forms.Button bt_8;
        private System.Windows.Forms.Button bt_9;
        private System.Windows.Forms.Button bt_6;
        private System.Windows.Forms.Button bt_5;
        private System.Windows.Forms.Button bt_4;
        private System.Windows.Forms.Button bt_3;
        private System.Windows.Forms.Button bt_2;
        private System.Windows.Forms.Button bt_1;
        private System.Windows.Forms.Button bt_0;
        private System.Windows.Forms.Button bt_vírgula;
        private System.Windows.Forms.Button bt_soma;
        private System.Windows.Forms.Button bt_subtração;
        private System.Windows.Forms.Button bt_multiplicação;
        private System.Windows.Forms.Button bt_divisão;
        private System.Windows.Forms.Button bt_igual;
        private System.Windows.Forms.Label lb_M;
        private System.Windows.Forms.Button bt_porcentagem;
    }
}

